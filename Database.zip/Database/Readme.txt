Update Claire's website
Get Windows 7
