vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|09 Jun 2006 01:11:56 -0000
vti_extenderversion:SR|5.0.2.4330
vti_timelastindexed:TW|10 Feb 2003 02:21:59 -0000
vti_lineageid:SR|{C1798047-4ADB-40F7-BACE-D7DD73C2287A}
vti_cacheddtm:TX|10 Feb 2003 02:21:59 -0000
vti_filesize:IR|98
vti_backlinkinfo:VX|
